
const products=[
{id:10,name:"🔥 CONTA FREE FIRE BRABA À VENDA 🔥 NV. 73 + 743 PEITAS",cat:"Contas Free Fire",price:199.90,discount:85,salePrice:29.90,fixedDiscount:true,tag:"OFERTA",symbol:"FF",tone:"",image:"https://ravenx-countdown-market.lovable.app/__l5e/assets-v1/fb9b0635-f532-43ed-8e7b-c21f381b1053/conta_nv73.png",desc:"Peitas: 743. Nível da Conta: Nv. 73 (conta antiga e respeitada). Patentes/Insígnias: Mestre com 129 medalhas e título de Rushador (10). Likes: quase 20 mil (19.921). Armas Evolutivas: várias no nível máximo (M1887 Lv. 7, MP40 Lv. 7 e M1014 Lv. 7). Itens e Skins: conta recheada de itens raros, peitas pesadas, calças angelicais/raras e combinações insanas para amassar no ranqueado."},
{id:11,name:"🔥 CONTA FREE FIRE À VENDA! NÍVEL 66",cat:"Contas Free Fire",price:129.90,discount:85,salePrice:19.90,fixedDiscount:true,tag:"OFERTA",symbol:"FF",tone:"",image:"https://ravenx-countdown-market.lovable.app/__l5e/assets-v1/84b45420-2380-4e10-99f8-5e855fb89644/conta_4.png",desc:"💎 Conta nível 66 · 👕 867 peitas · 👍 5.730 curtidas · 💰 141K de ouro · 💎 191 diamantes · 🔥 Conta recheada de itens raros! 📩 Interessados chamar no PV."},
{id:12,name:"🔥 CONTA FREE FIRE À VENDA! NÍVEL 84",cat:"Contas Free Fire",price:109.90,discount:85,salePrice:15.99,fixedDiscount:true,tag:"OFERTA",symbol:"FF",tone:"",image:"https://ravenx-countdown-market.lovable.app/__l5e/assets-v1/7f20a05e-8bc3-4a02-8deb-9a367cd0b3b1/conta_5.png",desc:"💎 Conta nível 84 · 👕 512 peitas · 👍 41.354 curtidas · 💰 326K de ouro · 💎 4 diamantes · 🔥 Itens de colaboração e roupas exclusivas! 📩 Interessados chamar no PV!"},
{id:13,name:"🔥 CONTA FREE FIRE À VENDA! NÍVEL 60",cat:"Contas Free Fire",price:69.90,discount:86,salePrice:9.99,fixedDiscount:true,tag:"OFERTA",symbol:"FF",tone:"",image:"https://ravenx-countdown-market.lovable.app/__l5e/assets-v1/0e44f9cc-c09d-47a0-9b3d-6e28e61d5106/conta_6.png",desc:"💎 Conta nível 60 · 👍 3.077 curtidas · 💰 28K de ouro · 💎 6 diamantes · 🔥 Personagens e skins de Naruto · 🔫 Skin de arma especial. 📩 Interessados chamar no PV!"},
{id:9,name:"CONTA DE FREE FIRE RARA | RAGNAROK | PASSE ANTIGO | EVOLUTIVA | SOMBRA ROXA",cat:"Contas Free Fire",price:189.90,discount:79,salePrice:43.90,fixedDiscount:true,tag:"OFERTA",symbol:"FF",tone:"",image:"https://i.imgur.com/93pxh65.png",desc:"Conta rara com conjunto Ragnarok, passe antigo, skin evolutiva e item Sombra Roxa. Uma seleção especial para quem procura itens antigos e cosméticos diferenciados no Free Fire."},
{id:28,name:"CONTA SUPER RARA VERIFICADA PRO | RECEBE ITENS GARENA",cat:"Contas Free Fire",price:320.00,discount:94,salePrice:16.90,fixedDiscount:true,tag:"OFERTA",symbol:"FF",tone:"",image:"https://ravenx-countdown-market.lovable.app/__l5e/assets-v1/c360482d-8943-4045-9d97-44ba916f1f93/conta_super_rara.jpg",shortDesc:"Conta Verificada PRO · recebe itens da Garena no correio · Banner LBFF 6 (2021) · +30 Passes de Elite · Angelicais Azul e Vermelha · 4 evolutivas no máximo.",desc:"📍 DETALHES GERAIS DA CONTA\n🔸 Status: CONTA VERIFICADA PRO ✅ (Raridade incomum no jogo!)\n🔸 Privilégio Exclusivo: Recebe itens da Garena direto no correio 🎁\n🔸 Perfil de altíssimo nível, respeitado por veteranos e colecionadores.\n———\n🏆 BANNERS E ITENS EXCLUSIVOS (NÍVEL MUNDIAL)\n🚩 Banner LBFF 6 de 2021 🌐 EXTREMAMENTE RARO: Apenas 40 contas no mundo possuem esse banner! ✨ Um verdadeiro troféu na sua conta para se destacar em qualquer lobby.\n———\n🎫 PASSES DE ELITE COLECIONÁVEIS\n🥇 Possui mais de 30 Passes de Elite no total\n👑 Conta com os raríssimos 1º e 2º Passe de Elite\n🏴‍☠️ Inclui o clássico Passe Pirata (Antigo) e o Passe 8 Bits\n🗓️ Coleção pesada de passes antigos: 1, 2, 5, 6, 9, 12, 13, 14, 15, 16 e 17.\n———\n😇 ANGELICAIS E CONJUNTOS RAROS\n💠 Possui as cobiçadas Angelicais Azul e Vermelha\n🎩 Conjunto Top Frifas\n🎭 Conjunto Maníaco do Golpe\n🌙 Conjunto Incubadora Lua Sangrenta\n☠️ Peste Negra\n🗑️ Cofre abarrotado com itens clássicos e muito mais!\n———\n🔫 ARMAMENTO E SKINS\n⚡ 4 Armas Evolutivas MAXIMIZADAS (No nível máximo!)\n🎯 UMP Atributada (Para amassar nas ranqueadas)\n🎯 XM8 Atributada\n👊 6 Punhos diferentes para você escolher\n💥 Arsenal completo e preparado para o competitivo.\n———\n🐾 MASCOTES E EXTRAS\n🛡️ Pet Poring (Clássico e muito procurado)\n🦺 Dezenas de outros itens raros espalhados pelo inventário.\n———\n🔐 SEGURANÇA E ACESSO\n📧 E-mail de recuperação de posse 100% livre.\n🔄 ALTERAÇÃO COMPLETA DE DADOS: Você poderá alterar tudo (e-mail, senha e vinculações) para o seu nome no momento da entrega."},
{id:29,name:"CONTA RARA JAQUETA ROUND SIX + FULL PARCERIA NARUTO & FULL ANGELICAL 👊",cat:"Contas Free Fire",price:400.00,discount:93,salePrice:24.90,fixedDiscount:true,tag:"OFERTA",symbol:"FF",tone:"",image:"https://ravenx-countdown-market.lovable.app/__l5e/assets-v1/55710aee-1cd3-4acc-b097-c5dd024db4ca/conta_round_six.jpg",shortDesc:"Jaqueta Round Six · Full parceria Naruto · Full Angelical · Rampage Edição Limitada · 14 armas evolutivas · 6 transformações.",desc:"RAMPAGE EDIÇÃO LIMITADA\nXM8 E UMP ATT 🔫\nPASSE BOOYAH\n11 ENTRADAS RARAS\nJUJUTSU KAISEN POSE KIT, SALTO, QUEDA FINALIZAÇÃO\nTOMADO PELAS AREIAS GOLPE FINAL\nRENASCER DA FÊNIX\n14 ARMAS EVOLUTIVAS\n6 TRANSFORMAÇÕES\n6 PUNHO 👊"},
{id:30,name:"CONTA LENDARIA + CABELO DE FITA 7P,5P + PEITORAL DO MANO MAX",cat:"Contas Free Fire",price:370.00,discount:95,salePrice:16.90,fixedDiscount:true,tag:"OFERTA",symbol:"FF",tone:"",image:"https://ravenx-countdown-market.lovable.app/__l5e/assets-v1/beb7cbcb-6c48-4b44-ad1f-79b58b623a00/conta_lendaria.jpg",shortDesc:"Calça angélical · cabelo sombra roxa · cabelo rosa · cabelo de fita 7P,5P · peitoral do Mano Max · +620 peitorais.",desc:"CALÇA ANGÉLICAL 🔴⚪\nCABELO SOMBRA ROXA 😮👉\nCABELO ROSA 😮👉\nCABELO DE FITA 7P,5P 🤩\nBANDEIRÃO 🔥\nBARBINHA DO BLACK 🔥\nCOELHÃO 🤩\nPEITORAL DO MANO MAX 🤩\nCAMISAS DE TIME 🤩\n+ DE 620 PEITORAIS E MUITO MAIS 🤩"},
{id:31,name:"CONTA PRIME NÍVEL 8 💉 + 800 PEITORAIS + BLUELOCK 🧸",cat:"Contas Free Fire",price:400.00,discount:95,salePrice:17.90,fixedDiscount:true,tag:"OFERTA",symbol:"FF",tone:"",image:"https://ravenx-countdown-market.lovable.app/__l5e/assets-v1/2251ec45-270f-4d00-a74b-4f48dd566df3/conta_prime8.jpg",shortDesc:"Prime 8 · 800 peitorais · Bluelock, Rampage, Naruto, Squid Game · Angelical (6 cores) · 15 evolutivas · 6 punhos.",desc:"> PRIME 8\n> 800 PEITORAIS\n> 2°,3°,4°,5°,7°,8° PASSE\n> BLUELOCK\n> RAMPAGE\n> NARUTO\n> SQUID GAME\n> SCORPION\n> JUJUTSU KAYSEN\n> ANGELICAL 🔵🟡🟣🟢🔴⚪\n> GALÁXIA 5p e 7p\n> MÁSCARA SORRISINHO\n> 15 EVOLUTIVAS\n> 6 PUNHOS\n> UMP 🟡 ATT"},
{id:32,name:"CONTA FULL LUA SANGRENTA 7P + PASSE SAKURA + 9K DE DIMAS",cat:"Contas Free Fire",price:420.00,discount:95,salePrice:17.90,fixedDiscount:true,tag:"OFERTA",symbol:"FF",tone:"",image:"https://ravenx-countdown-market.lovable.app/__l5e/assets-v1/da18dbde-2dd1-4a33-838c-510872591492/conta_lua_sangrenta.jpg",shortDesc:"Full Lua Sangrenta 7p · Prime 8 · +1250 peitorais · nível 87 · 9K de diamantes · 10 punhos · M1014 Attack on Titan.",desc:"FULL LUA SANGRENTA 7p\nPRIME 8\n😶 +1250 PEITORAL\n😨 NIVEL 87 - 9K DE DIMAS 💎\n🔥 10 PUNHOS - TEM OPM ✅\n😱 FITINHA 7p\n🤩 MARIONETE 7p\n🥶 M1014 ATTACK ON TITAN\n❤️🔥 FULL FITINHA\n😬 SOLDADO V. 7p\n🌚 PASSE SAKURA (1º)\n🍀 PASSE HIP HOP (2º)\n😶 PASSE PRECURSOR (3º)\n😨 PASSE REALEZA (4º)\n🔥 PASSE STEAMPUNK (7º)\n😱 GALÁXIA 7p"},
{id:33,name:"CONTA RARIDADE PRIME 8 + 1259 PEITORAIS ✅",cat:"Contas Free Fire",price:450.00,discount:95,salePrice:20.90,fixedDiscount:true,tag:"OFERTA",symbol:"FF",tone:"",image:"https://ravenx-countdown-market.lovable.app/__l5e/assets-v1/6daa1eb5-d232-4ee1-84e8-dfd01ddf0208/conta_raridade_prime8.jpg",shortDesc:"Prime 8 · 116K de likes · LVL 81 · +1259 peitorais · 5 angelicais · 6 passes · cabelo rosa · skins Jujutsu Kaisen e Naruto.",desc:"PRIME 8\n116K DE LIKE\nLVL81\n+ 1259 PEITORAIS\n5 ANGELICAIS\n6 PASSE\nCABELO ROSA\nBLUELOCK\nBARBINHA\nFITINHA FULL\nPÉ DESCALÇO\nAVENTUREIRO\nTODAS AS SKIN JUJUTSU KAISEN\nTODAS AS SKIN NARUTO\nUMP ATT\nXM8 ATT"},
{id:34,name:"CONTA PRIME 6 NV. 76 + ANGELICAL + 17 PASSES DE ELITE",cat:"Contas Free Fire",price:19.99,fixedDiscount:true,tag:"NOVA",symbol:"FF",tone:"",image:"https://ravenx-countdown-market.lovable.app/__l5e/assets-v1/073f8934-498a-4cba-8073-7ff593448513/conta_prime6.jpg",shortDesc:"Prime 6 · Nv. 76 · Angelical masculina · 17 passes de elite · Punho dracônico LV.5 · AK Chama do Dragão LV.5 · P90 Corrosão Dourada LV.4.",desc:"💎 ANGELICAL:\n* MASCULINA: 💜\n\nDESTAQUES:\n- Barbinha\n- Gola alta preta\n- Punho dracônico: LV.5\n- Punho acorrentado\n- Parceria La Casa de Papel\n- Skins parceria X Naruto\n- Skins parceria X Jujutsu Kaisen\n- Conjunto unissex Luz Boreal\n- Conjunto unissex Sombra Boreal\n- Entrada de lobby: Chegada Boreal\n- Passes de elite: 17 completos\n- Armas evolutivas:\nP90 - Corrosão dourada LV. 4\nAK - Chama do dragão LV. 5"},
{id:35,name:"CONTA FREE FIRE PRIME 5",cat:"Contas Free Fire",price:22.99,fixedDiscount:true,tag:"NOVA",symbol:"FF",tone:"",image:"https://ravenx-countdown-market.lovable.app/__l5e/assets-v1/50877601-ad73-4780-bd0f-f88a39ef0d0d/conta_prime5.jpg",shortDesc:"Prime 5 · Nv. 71 · segundo passe completo · 30 passes de elite · angelical azul · bandeirão · sombra roxa · conjuntos Mano Max e Samurai Escarlate.",desc:"CONTA FREE FIRE PRIME 5\n\nSEGUNDO PASSE COMPLETO\n30 PASSES DE ELITE\nANGELICAL AZUL\nBANDEIRÃO\nSOMBRA ROXA\n1 ANIMAÇÃO DE ENTRADA\nMESTRES ANTIGOS\nCONJUNTO MANO MAX\nCONJUNTO SAMURAI ESCARLATE\nE MUITO MAIS\n\nLOGIN GMAIL VIRGEM\nPODE ALTERAR TODOS OS DADOS"},
{id:36,name:"CONTA FREE FIRE NV. 78 + 26.800 LIKES + PASSES ANTIGOS",cat:"Contas Free Fire",price:35.00,fixedDiscount:true,tag:"NOVA",symbol:"FF",tone:"",image:"https://ravenx-countdown-market.lovable.app/__l5e/assets-v1/84708264-69ac-42e9-b108-d98dc1425a72/conta_nv78.jpg",shortDesc:"Nv. 78 · +26.800 likes · passes antigos (Sakura, Hip Hop, Precursor...) · 5 calças angelicais · incubadoras gemadas · UMP e XM8 atributadas.",desc:"Level 78 e 26800+ likes 🏅\n\ncontem quase todos os primeiros passes: ( 1º Sakura / 2º Hip Hop / 3º Precursor / 5º Ilha do Tesouro / 7º Steampunk / 8º Choque Impulsivo ) raridade única ✨\n\nmuita ump e xm8 atributadas, ótimo para apostados 🥇\n( tem varias outras armas atributadas tambem ) ✨\n\nALGUMAS INFORMAÇÕES DA PARTE DAS SKINS 👕\n\n8 incubadoras 7 pedras gemadas ( ayakashi das flores / coelho atomico / top criminal vermelho / cristal estelar / sombra dourada / mc gemadão / vermelho flamejante / miko das flores )\n\n5 calças angelicais ( azul masculina / vermelha masculina / verde masculina / azul feminina / vermelha feminina )\n\n5 camisas do biscoito raras ( bolacha roxa / bolacha verde / bolacha teal / bolacha marrom / bolacha azul )\n\n3 incubadoras 5 pedras gemadas ( mc coringão / ayakashi das chamas / miko das chamas )\n\nrecheada de skins de parcerias e eventos muito brabas:\n( sasuke / nagi - time V / naruto / kakashi / escorpião escarlate / cobra: modo furia / plano bermuda shinobi / tengen uzui )\n\nALGUMAS INFORMAÇÕES DE COFRE E ARSENAL 🔫\n\ntem punhos ( nocauteador / cobra )\n\ntem mudança de visual ( naruto )\n\ntem animação de entrada ( viajando no tempo )\n\ntem arma evolutiva ( MP40 - Cobra Venenosa )\n\ntem animação de finalização ( corte flamejante )"},
{id:14,name:"CODIGUIN CALÇA ANGELICAL AMARELA",cat:"Códiguins",price:60.00,discount:78,salePrice:14.90,fixedDiscount:true,tag:"CODIGUIN",symbol:"⌁",tone:"gold",image:"https://ravenx-countdown-market.lovable.app/__l5e/assets-v1/97f5d2f2-258b-420d-88a0-830cddc2d0de/codiguin_12.png",desc:"Codiguin da Calça Angelical Amarela. 100% seguro, prêmios exclusivos, itens raros e resgate rápido."},
{id:15,name:"CODIGUIN CALÇA ANGELICAL AZUL",cat:"Códiguins",price:60.00,discount:78,salePrice:14.90,fixedDiscount:true,tag:"CODIGUIN",symbol:"⌁",tone:"gold",image:"https://ravenx-countdown-market.lovable.app/__l5e/assets-v1/81a98814-1562-4176-ac00-752526ed93db/codiguin_9.png",desc:"Codiguin da Calça Angelical Azul. 100% seguro, prêmios exclusivos, itens raros e resgate rápido."},
{id:16,name:"CODIGUIN MP5 FASCÍNIO",cat:"Códiguins",price:70.00,discount:78,salePrice:14.90,fixedDiscount:true,tag:"CODIGUIN",symbol:"⌁",tone:"gold",image:"https://ravenx-countdown-market.lovable.app/__l5e/assets-v1/d81b817c-22bf-4d27-82b6-dd90e0f24528/codiguin_10.png",desc:"MP5 Fascínio + 800 tokens. Quem já pegou a arma pode adquirir o código para obter os tokens. Resgate em reward.ff.garena.com."},
{id:17,name:"CODIGUIN PUNHO PATADA DE OURO",cat:"Códiguins",price:70.00,discount:78,salePrice:14.90,fixedDiscount:true,tag:"CODIGUIN",symbol:"⌁",tone:"gold",image:"https://ravenx-countdown-market.lovable.app/__l5e/assets-v1/a0c8bfa7-6db7-445f-bc29-b6c2360033dd/codiguin_11.png",desc:"Novo Punho Patada de Ouro, lançamento exclusivo. Resgate em reward.ff.garena.com e receba a recompensa no cofre."},

{id:18,name:"110 Diamantes 💎",cat:"Diamantes",price:5.90,discount:33,salePrice:3.90,fixedDiscount:true,tag:"ESGOTADO",symbol:"◇",tone:"blue",image:"https://ravenx-countdown-market.lovable.app/__l5e/assets-v1/8805980e-e311-44d4-8806-0b33073bd1e2/diamantes.jpg",soldOut:true,desc:"Pacote de 110 diamantes para Free Fire. À vista no Pix."},
{id:19,name:"341 Diamantes 💎",cat:"Diamantes",price:9.90,discount:20,salePrice:7.90,fixedDiscount:true,tag:"AUTOMÁTICA",symbol:"◇",tone:"blue",image:"https://ravenx-countdown-market.lovable.app/__l5e/assets-v1/8805980e-e311-44d4-8806-0b33073bd1e2/diamantes.jpg",desc:"Pacote de 341 diamantes para Free Fire. À vista no Pix."},
{id:20,name:"572 Diamantes 💎",cat:"Diamantes",price:34.90,discount:57,salePrice:14.90,fixedDiscount:true,tag:"AUTOMÁTICA",symbol:"◇",tone:"blue",image:"https://ravenx-countdown-market.lovable.app/__l5e/assets-v1/8805980e-e311-44d4-8806-0b33073bd1e2/diamantes.jpg",desc:"Pacote de 572 diamantes para Free Fire. À vista no Pix."},
{id:21,name:"1166 Diamantes 💎",cat:"Diamantes",price:29.90,discount:36,salePrice:18.90,fixedDiscount:true,tag:"AUTOMÁTICA",symbol:"◇",tone:"blue",image:"https://ravenx-countdown-market.lovable.app/__l5e/assets-v1/8805980e-e311-44d4-8806-0b33073bd1e2/diamantes.jpg",desc:"Pacote de 1166 diamantes para Free Fire. À vista no Pix."},
{id:22,name:"2398 Diamantes 💎",cat:"Diamantes",price:39.90,discount:50,salePrice:19.90,fixedDiscount:true,tag:"AUTOMÁTICA",symbol:"◇",tone:"blue",image:"https://ravenx-countdown-market.lovable.app/__l5e/assets-v1/8805980e-e311-44d4-8806-0b33073bd1e2/diamantes.jpg",desc:"Pacote de 2398 diamantes para Free Fire. À vista no Pix."},
{id:23,name:"TOKEN DE TRANSFERÊNCIA",cat:"Serviços",price:57.90,discount:77,salePrice:12.90,fixedDiscount:true,tag:"SERVIÇO",symbol:"♛",tone:"gold",image:"https://ravenx-countdown-market.lovable.app/__l5e/assets-v1/c9a476c8-f75e-4448-8f8c-fb5e088be685/servico-token.jpg",desc:"Token de transferência para Free Fire."},
{id:24,name:"🆔 VERIFICAÇÃO DE IDENTIDADE ANTI-RECUPERAÇÃO",cat:"Serviços",price:99.90,discount:80,salePrice:19.90,fixedDiscount:true,tag:"SERVIÇO",symbol:"♛",tone:"gold",image:"https://ravenx-countdown-market.lovable.app/__l5e/assets-v1/59f1c8a4-a9bc-4ac4-be4b-b9ef9df7536d/servico-verificacao.jpg",desc:"Verificação de identidade anti-recuperação com garantia vitalícia."},
{id:25,name:"🛡️ UPGRADE ANTI-BLOQUEIO",cat:"Serviços",price:99.90,discount:92,salePrice:7.90,fixedDiscount:true,tag:"SERVIÇO",symbol:"♛",tone:"gold",image:"https://ravenx-countdown-market.lovable.app/__l5e/assets-v1/4f4c59d5-2d88-4a25-b7f6-57c67b6c4245/servico-upgrade.jpg",desc:"Upgrade anti-bloqueio para Free Fire."},
{id:26,name:"PRIORIDADE NO PEDIDO - LEGACY FF",cat:"Serviços",price:129.90,discount:87,salePrice:15.90,fixedDiscount:true,tag:"SERVIÇO",symbol:"♛",tone:"gold",image:"https://ravenx-countdown-market.lovable.app/__l5e/assets-v1/bdd2092b-bc33-442c-a860-b973fbf0fbf6/servico-prioridade.jpg",desc:"Prioridade no pedido - Legacy FF."},
{id:27,name:"🔰 REEMBOLSO DE TODAS AS TAXAS - ZINEX LEGACY FF",cat:"Serviços",price:69.90,discount:81,salePrice:12.90,fixedDiscount:true,tag:"SERVIÇO",symbol:"♛",tone:"gold",image:"https://ravenx-countdown-market.lovable.app/__l5e/assets-v1/36811f44-0664-4c47-ab64-9f139d3cbafc/servico-reembolso.png",desc:"Reembolso de todas as taxas - Zinex Legacy FF."},
];
// Descontos aleatórios persistidos no navegador para não mudarem a cada atualização.
const discountKey="ravenx-account-discounts";
let accountDiscounts={};
try{accountDiscounts=JSON.parse(localStorage.getItem(discountKey)||"{}")||{}}catch(e){accountDiscounts={}}
products.filter(p=>p.cat.startsWith("Contas")&&!p.noDiscount&&p.id!==9).forEach(p=>{
 if(!accountDiscounts[p.id])accountDiscounts[p.id]=Math.floor(Math.random()*25)+51;
});
localStorage.setItem(discountKey,JSON.stringify(accountDiscounts));
products.forEach(p=>{if(p.fixedDiscount){}else{p.discount=accountDiscounts[p.id]||0;p.salePrice=Number((p.price*(1-p.discount/100)).toFixed(2))}});
const currentPrice=p=>p.salePrice??p.price;
let category="Todos",cart=JSON.parse(localStorage.getItem("ravenx-cart")||"[]");
const money=n=>n.toLocaleString("pt-BR",{style:"currency",currency:"BRL"});
function renderCategories(){const cats=["Todos",...new Set(products.map(p=>p.cat))];document.getElementById("categories").innerHTML=cats.map(c=>'<button type="button" class="chip '+(c===category?'active':'')+'" data-category="'+c+'" aria-pressed="'+(c===category)+'">'+c+'</button>').join("")}
function setCategory(c){category=c;renderCategories();render()}
function render(){
 const q=document.getElementById("search").value.trim().toLocaleLowerCase("pt-BR");
 let list=products.filter(p=>(category==="Todos"||p.cat===category)&&(p.name+" "+p.cat+" "+p.desc).toLocaleLowerCase("pt-BR").includes(q));
 const sort=document.getElementById("sort").value;
 if(sort==="low")list.sort((a,b)=>currentPrice(a)-currentPrice(b));
 if(sort==="high")list.sort((a,b)=>currentPrice(b)-currentPrice(a));
 const grid=document.getElementById("products");
 const groups=category==="Todos"?[...new Set(products.map(p=>p.cat))]:[category];
 const baseCard=p=>'<article class="product-card" onclick="openDetails('+p.id+')"><div class="product-visual '+p.tone+'">'+(p.image?'<img class="product-photo" src="'+p.image+'" alt="'+p.name+'" loading="lazy" onerror="this.style.display=\'none\'">':'<span class="symbol">'+p.symbol+'</span>')+'<span class="product-tag">'+p.tag+'</span>'+(p.discount?'<span class="discount-tag">-'+p.discount+'%</span>':'')+'</div><div class="product-body"><div class="product-category">'+p.cat+'</div><h3>'+p.name+'</h3><p class="product-description">'+(p.shortDesc||p.desc)+'</p><div class="product-foot"><div class="price-stack">'+(p.discount?'<span class="old-price">'+money(p.price)+'</span>':'')+'<span class="price-label">'+(p.discount?'POR':'PREÇO')+'</span><span class="price">'+money(currentPrice(p))+'</span></div></div><div class="buy-row"><button class="buy-btn" onclick="event.stopPropagation();buyNow('+p.id+')">Comprar</button><button class="bag-btn" aria-label="Adicionar ao carrinho" onclick="event.stopPropagation();addToast('+p.id+')"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8h16l-1.2 11.2a2 2 0 0 1-2 1.8H7.2a2 2 0 0 1-2-1.8L4 8z"/><path d="M8.5 11V7a3.5 3.5 0 0 1 7 0v4"/></svg></button></div></div></article>';
 const card=p=>{
   let h=baseCard(p);
   if(p.soldOut){
     h=h.replace('class="product-card"','class="product-card sold-out"')
        .replace('<span class="product-tag">','<span class="sold-out-label">ESGOTADO</span><span class="product-tag">')
        .replace(/<div class="buy-row">[\s\S]*<\/div><\/article>/,'<div class="buy-row"><button class="buy-btn" onclick="event.stopPropagation();openDetails('+p.id+')">Ver detalhes</button></div></div></article>');
   }
   return h;
 };
 grid.innerHTML=groups.map(cat=>{
   const items=list.filter(p=>p.cat===cat);
   if(!items.length)return "";
   return '<section class="category-group"><div class="category-heading"><span>'+cat+'</span><small>'+items.length+' '+(items.length===1?'produto':'produtos')+'</small></div><div class="product-grid">'+items.map(card).join("")+'</div></section>';
 }).join("");
 document.getElementById("empty").style.display=list.length?"none":"block";
}
document.getElementById("categories").addEventListener("click",event=>{const button=event.target.closest("[data-category]");if(button)setCategory(button.dataset.category)});
document.getElementById("search").addEventListener("input",render);
document.getElementById("sort").addEventListener("change",render);
let detailProduct=null;
function openDetails(id){detailProduct=products.find(p=>p.id===id);if(!detailProduct)return;document.getElementById("detailCategory").textContent=detailProduct.cat;document.getElementById("detailName").textContent=detailProduct.name;document.getElementById("detailPrice").innerHTML=(detailProduct.discount?'<span class="detail-old-price">'+money(detailProduct.price)+'</span><span class="detail-discount">-'+detailProduct.discount+'% DE DESCONTO</span>':'')+money(currentPrice(detailProduct));document.getElementById("detailDescription").textContent=detailProduct.desc+" Confira as informações do anúncio antes de finalizar.";document.getElementById("detailFeatures").innerHTML="<li>Produto selecionado no catálogo</li><li>Preço visível antes da compra</li><li>Entrega pelo e-mail informado no checkout</li>";document.getElementById("detailMainImage").className="detail-main-image "+detailProduct.tone;document.getElementById("detailMainImage").innerHTML=detailProduct.image?'<img class="detail-photo" src="'+detailProduct.image+'" alt="'+detailProduct.name+'" onerror="this.outerHTML=\'<span class=\\\'symbol\\\'>FF</span>\'">':'<span class="symbol" id="detailSymbol">'+detailProduct.symbol+'</span>';document.querySelectorAll(".detail-thumb").forEach((b,i)=>b.classList.toggle("active",i===0));document.getElementById("detailAdd").onclick=()=>{add(detailProduct.id,true);closeDetails();openCart()};document.getElementById("detailAdd").style.display=detailProduct.soldOut?"none":"";document.getElementById("details").classList.add("open")}
function setDetailImage(i){if(detailProduct.image)return;const symbols=[detailProduct.symbol,"✦","◆"];document.getElementById("detailSymbol").textContent=symbols[i];document.querySelectorAll(".detail-thumb").forEach((b,n)=>b.classList.toggle("active",n===i));const tones=["","violet","blue"];document.getElementById("detailMainImage").className="detail-main-image "+(tones[i]||detailProduct.tone)}
function closeDetails(){document.getElementById("details").classList.remove("open")}
function add(id,silent){const pr=products.find(p=>p.id===id);if(!pr||pr.soldOut)return;const item=cart.find(x=>x.id===id);if(item)item.qty++;else cart.push({id,qty:1});saveCart();if(!silent)notify("Adicionado ao carrinho",pr.name+" · "+pr.cat)}
function saveCart(){
 localStorage.setItem("ravenx-cart",JSON.stringify(cart));
 document.getElementById("count").textContent=cart.reduce((n,x)=>n+x.qty,0);
 const html=cart.map(x=>{
  const p=products.find(y=>y.id===x.id);if(!p)return "";
  return '<article class="cart-product"><div class="cart-product-visual '+p.tone+'">'+(p.image?'<img src="'+p.image+'" alt="'+p.name+'">':'<span>'+p.symbol+'</span>')+'</div><div class="cart-product-info"><span class="cart-product-category">'+p.cat+'</span><strong>'+p.name+'</strong><small><span class="cart-price-stack">'+(p.discount?'<s class="cart-old-price">'+money(p.price)+'</s>':'')+'<span>'+money(currentPrice(p))+' cada'+(p.discount?' · <b class="cart-discount">-'+p.discount+'%</b>':'')+'</span></span></small><div class="cart-qty"><button type="button" aria-label="Diminuir quantidade" onclick="changeQty('+p.id+',-1)">−</button><b>'+x.qty+'</b><button type="button" aria-label="Aumentar quantidade" onclick="changeQty('+p.id+',1)">+</button><button type="button" class="cart-remove" onclick="removeItem('+p.id+')">Remover</button></div></div><strong class="cart-product-subtotal">'+money(currentPrice(p)*x.qty)+'</strong></article>';
 }).join("");
 document.getElementById("cartItems").innerHTML=html||'<div class="cart-empty"><span>🛒</span><strong>Seu carrinho está vazio</strong><small>Adicione um produto para vê-lo aqui.</small></div>';
 document.getElementById("total").textContent=money(cart.reduce((n,x)=>{const p=products.find(y=>y.id===x.id);return n+(p?currentPrice(p)*x.qty:0)},0));
}
function changeQty(id,delta){const item=cart.find(x=>x.id===id);if(!item)return;item.qty+=delta;if(item.qty<=0)cart=cart.filter(x=>x.id!==id);saveCart()}
function removeItem(id){cart=cart.filter(x=>x.id!==id);saveCart()}
function openCart(){saveCart();document.getElementById("cart").classList.add("open")}function closeCart(){document.getElementById("cart").classList.remove("open")}
function checkout(){if(!cart.length){alert("Adicione um produto ao carrinho.");return}closeCart();document.getElementById("email").value="";document.getElementById("confirmEmail").value="";document.getElementById("emailError").style.display="none";document.getElementById("checkout").classList.add("open")}function closeCheckout(){document.getElementById("checkout").classList.remove("open")}
function saveOrder(){const email=document.getElementById("email").value.trim().toLowerCase();const confirmEmail=document.getElementById("confirmEmail").value.trim().toLowerCase();const valid=/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);const error=document.getElementById("emailError");if(!valid){error.textContent="Informe um e-mail válido para entrega.";error.style.display="block";return}if(email!==confirmEmail){error.textContent="Os e-mails não coincidem. Confira os dois campos.";error.style.display="block";document.getElementById("confirmEmail").focus();return}error.style.display="none";const orders=JSON.parse(localStorage.getItem("ravenx-preorders")||"[]");orders.push({id:"RX-"+Date.now(),deliveryEmail:email,items:cart,total:cart.reduce((n,x)=>n+currentPrice(products.find(p=>p.id===x.id))*x.qty,0),status:"Pré-pedido — aguardando integração Pix",createdAt:new Date().toISOString()});localStorage.setItem("ravenx-preorders",JSON.stringify(orders));cart=[];saveCart();closeCheckout();alert("Pré-pedido salvo neste dispositivo. Nenhum pagamento foi realizado.")}
document.querySelectorAll(".overlay").forEach(el=>el.addEventListener("click",e=>{if(e.target===el)el.classList.remove("open")}));renderCategories();render();saveCart();

;

(function(){
 const output=document.getElementById("heroCountdown");
 if(!output)return;
 const duration=43*60*1000;
 const storageKey="ravenx-hero-countdown-end-43m";
 let deadline=Number(localStorage.getItem(storageKey));
 if(!Number.isFinite(deadline)||deadline<=Date.now()){
   deadline=Date.now()+duration;
   localStorage.setItem(storageKey,String(deadline));
 }
 function updateCountdown(){
   let remaining=deadline-Date.now();
   if(remaining<=0){
     deadline=Date.now()+duration;
     localStorage.setItem(storageKey,String(deadline));
     remaining=duration;
   }
   const hours=Math.floor(remaining/3600000);
   const minutes=Math.floor((remaining%3600000)/60000);
   const seconds=Math.floor((remaining%60000)/1000);
   output.innerHTML='<span>'+String(hours).padStart(2,'0')+'</span><i>:</i><span>'+String(minutes).padStart(2,'0')+'</span><i>:</i><span>'+String(seconds).padStart(2,'0')+'</span>';
 }
 updateCountdown();
 setInterval(updateCountdown,1000);
})();

;
function renderCheckout(){const box=document.getElementById("coItems");if(!box)return;const n=cart.reduce((a,x)=>a+x.qty,0);document.getElementById("coCount").textContent=n+(n===1?" item":" itens");box.innerHTML=cart.length?cart.map(x=>{const p=products.find(q=>q.id===x.id);if(!p)return"";return'<div class="co-item"><div class="co-thumb '+p.tone+'">'+(p.image?'<img src="'+p.image+'" alt="">':'<span>'+p.symbol+'</span>')+'</div><div class="co-info"><strong>'+p.name+'</strong><small>1 disponível</small><button class="co-remove" onclick="removeItem('+p.id+')">🗑 REMOVER</button></div><div class="co-side"><div class="co-prices">'+(p.discount?'<s>'+money(p.price)+'</s>':'')+'<b>'+money(currentPrice(p))+'</b></div><div class="co-qty"><button onclick="changeQty('+p.id+',-1)">-</button><span>'+x.qty+'</span><button onclick="changeQty('+p.id+',1)">+</button></div></div></div>'}).join(""):'<p class="co-empty">Seu carrinho está vazio.</p>';const t=money(cart.reduce((a,x)=>{const p=products.find(q=>q.id===x.id);return a+(p?currentPrice(p)*x.qty:0)},0));document.getElementById("coSubtotal").textContent=t;document.getElementById("coTotal").textContent=t}
(function(){const orig=saveCart;saveCart=function(){orig.apply(this,arguments);renderCheckout()}})();
const _origCheckout=checkout;checkout=function(){_origCheckout();renderCheckout();window.scrollTo(0,0)};
function applyCoupon(){const c=prompt("Digite seu cupom de desconto:");if(c)alert("Cupom inválido ou expirado.")}

;function buyNow(id){const pr=products.find(p=>p.id===id);if(!pr||pr.soldOut)return;if(!cart.find(x=>x.id===id))add(id,true);closeCart();checkout()}

;/* Aviso no topo (toast) — só para eventos reais da loja */
(function(){
 var box,timer;
 function ensure(){
  if(box)return box;
  box=document.createElement("div");
  box.className="rx-toast";
  box.setAttribute("role","status");
  box.setAttribute("aria-live","polite");
  box.addEventListener("click",hide);
  document.body.appendChild(box);
  return box;
 }
 function esc(t){return String(t).replace(/[&<>"]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]})}
 function hide(){if(box)box.classList.remove("show");clearTimeout(timer)}
 window.notify=function(title,sub){
  var el=ensure();
  el.innerHTML='<div class="rx-toast-head"><span class="rx-toast-app">RX<img src="https://ravenx-countdown-market.lovable.app/__l5e/assets-v1/66c36b40-600b-4795-9972-c85fc6905851/capa.png" alt="" onerror="this.style.display=\'none\'"></span><span class="rx-toast-name">Ravenx Store</span><span class="rx-toast-time">agora</span></div><div class="rx-toast-body"><span class="rx-toast-check"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></span><div class="rx-toast-text"><strong>'+esc(title)+'</strong><small>'+esc(sub||"")+'</small></div></div>';
  el.classList.remove("show");void el.offsetWidth;el.classList.add("show");
  clearTimeout(timer);timer=setTimeout(hide,3600);
 };
})();
function addToast(id){const p=products.find(x=>x.id===id);if(!p||p.soldOut)return;add(id);notify("Adicionado ao carrinho",p.name)}

;/* Aviso no topo (toast) da Ravenx. Use notify(titulo, subtitulo) apenas para eventos reais:
   ex.: notify("Pagamento confirmado","Pedido RX-123"), notify("Pedido saiu para entrega","Pedido RX-123") */
var _toastTimer=null;
function notify(title,sub){
 var old=document.getElementById("rxToast");if(old)old.remove();clearTimeout(_toastTimer);
 var el=document.createElement("div");el.id="rxToast";el.className="rx-toast";el.setAttribute("role","status");el.setAttribute("aria-live","polite");
 el.innerHTML='<div class="rx-toast-head"><span class="rx-toast-logo"><img src="https://ravenx-countdown-market.lovable.app/__l5e/assets-v1/66c36b40-600b-4795-9972-c85fc6905851/capa.png" alt="" onerror="this.outerHTML=\'R\'"></span><span class="rx-toast-brand">RAVENX STORE</span><span class="rx-toast-time">agora</span></div><div class="rx-toast-body"><span class="rx-toast-check"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></span><div class="rx-toast-text"><strong></strong><small></small></div></div>';
 el.querySelector("strong").textContent=title;el.querySelector("small").textContent=sub||"";
 el.addEventListener("click",function(){el.classList.remove("show");setTimeout(function(){el.remove()},250)});
 document.body.appendChild(el);
 requestAnimationFrame(function(){requestAnimationFrame(function(){el.classList.add("show")})});
 _toastTimer=setTimeout(function(){el.classList.remove("show");setTimeout(function(){el.remove()},300)},3500);
}

;/* Checkout Pix — SmokePay */
(function(){
 var poll=null,ov=null;
 function el(){
  if(ov)return ov;
  ov=document.createElement("div");ov.className="overlay";ov.id="pixPay";
  ov.innerHTML='<div class="panel pix-panel"><div class="panel-head"><h2>Pague com Pix</h2><button class="close" aria-label="Fechar" onclick="rxClosePix()">×</button></div><div id="pixBody"></div></div>';
  document.body.appendChild(ov);return ov;
 }
 window.rxClosePix=function(){if(poll)clearInterval(poll);poll=null;if(ov)ov.classList.remove("open")};
 function body(h){el().classList.add("open");document.getElementById("pixBody").innerHTML=h}
 function paid(){if(poll)clearInterval(poll);poll=null;cart=[];saveCart();body('<div class="pix-done"><div class="pix-check">✓</div><strong>Pagamento confirmado!</strong><p class="panel-hint">Recebemos seu Pix. A entrega será feita no e-mail informado no pedido.</p><button class="full-btn" onclick="rxClosePix()">Voltar à loja</button></div>')}
 saveOrder=async function(){
  var email=document.getElementById("email").value.trim().toLowerCase(),c=document.getElementById("confirmEmail").value.trim().toLowerCase(),err=document.getElementById("emailError");
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){err.textContent="Informe um e-mail válido para entrega.";err.style.display="block";return}
  if(email!==c){err.textContent="Os e-mails não coincidem. Confira os dois campos.";err.style.display="block";return}
  err.style.display="none";
  if(!window.rxPix){alert("Carregando pagamento, tente de novo em instantes.");return}
  closeCheckout();body('<p class="panel-hint">Gerando seu Pix...</p>');
  try{
   var r=await window.rxPix.create({email:email,items:cart.map(function(x){return{id:x.id,qty:x.qty}})});
   body('<div class="pix-total">Total: <b>'+money(r.total)+'</b></div>'+(r.qrCode?'<img class="pix-qr" src="'+r.qrCode+'" alt="QR Code Pix">':'')+'<label class="panel-hint">Pix copia e cola</label><textarea class="field pix-code" readonly id="pixCode"></textarea><button class="full-btn" id="pixCopy">Copiar código Pix</button><p class="panel-hint pix-wait">⏳ Aguardando pagamento... esta tela atualiza sozinha quando o Pix for pago. O código vale por 30 minutos.</p>');
   document.getElementById("pixCode").value=r.pixCopiaCola;
   document.getElementById("pixCopy").onclick=function(){navigator.clipboard.writeText(r.pixCopiaCola).then(function(){document.getElementById("pixCopy").textContent="Código copiado ✓"})};
   if(poll)clearInterval(poll);
   poll=setInterval(async function(){try{var s=await window.rxPix.status(r.orderId);if(s.status==="paid")paid();else if(s.status==="expired"||s.status==="cancelled"){clearInterval(poll);poll=null;body('<p class="panel-hint">Este Pix expirou. Volte ao carrinho para gerar um novo.</p><button class="full-btn" onclick="rxClosePix();openCart()">Voltar ao carrinho</button>')}}catch(e){}},5000);
  }catch(e){body('<p class="panel-hint">'+(e&&e.message?String(e.message).replace(/</g,"&lt;"):"Não foi possível gerar o Pix.")+'</p><button class="full-btn" onclick="rxClosePix();checkout()">Tentar novamente</button>')}
 };
})();
