# RAVENX STORE — GitHub Pages

A pasta `docs/` contém a versão estática preparada para GitHub Pages.

## Publicar
1. Envie o conteúdo deste pacote para a branch `main` do repositório.
2. No GitHub, abra **Settings → Pages**.
3. Em **Build and deployment**, escolha **Deploy from a branch**.
4. Selecione a branch `main` e a pasta `/docs`, depois clique em **Save**.
5. Aguarde a publicação e abra o endereço exibido na seção Pages.

## Limitações
- Catálogo, busca, filtros, detalhes e carrinho rodam no navegador.
- GitHub Pages não executa backend. O checkout Pix real e a confirmação automática estão desativados nesta versão.
- As imagens dos produtos apontam para o armazenamento de assets do projeto Lovable original. Se esse armazenamento ficar indisponível, será necessário copiar as imagens para `docs/assets/` e atualizar os caminhos.
- Não publique chaves secretas/API no repositório.
